#!/bin/sh
# Crystal Ball installer for any Linux distribution.
#
#   ./install.sh               install for everyone into /usr/local (asks for sudo)
#   ./install.sh --user        install just for you into ~/.local (no sudo)
#   ./install.sh --deps        also install the dependencies with your package manager
#   ./install.sh --uninstall   remove it again (add --user if you installed with --user)
set -e

HERE=$(cd "$(dirname "$0")" && pwd)
MODE=system
DEPS=no
ACTION=install
for arg in "$@"; do
  case "$arg" in
    --user) MODE=user ;;
    --deps) DEPS=yes ;;
    --uninstall) ACTION=uninstall ;;
    -h|--help) sed -n '2,8p' "$0"; exit 0 ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

if [ "$MODE" = user ]; then
  PREFIX="${XDG_DATA_HOME:-$HOME/.local/share}/.."
  PREFIX=$(cd "$PREFIX" 2>/dev/null && pwd || echo "$HOME/.local")
  SUDO=
else
  PREFIX=/usr/local
  if [ "$(id -u)" -eq 0 ]; then SUDO=; elif command -v sudo >/dev/null 2>&1; then SUDO=sudo; else SUDO="su -c"; fi
fi

run() {
  if [ -z "$SUDO" ]; then "$@"; elif [ "$SUDO" = sudo ]; then sudo "$@"; else su -c "$*"; fi
}

# ------------------------------------------------------------------ dependencies

. /etc/os-release 2>/dev/null || true
FAMILY="$ID $ID_LIKE"

deps_command() {
  case "$FAMILY" in
    *debian*|*ubuntu*|*raspbian*) echo "apt-get install -y python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.1" ;;
    *fedora*|*rhel*|*centos*) echo "dnf install -y python3-gobject gtk3 webkit2gtk4.1" ;;
    *suse*) echo "zypper --non-interactive install python3-gobject python3-gobject-Gdk typelib-1_0-Gtk-3_0 typelib-1_0-WebKit2-4_1" ;;
    *arch*) echo "pacman -S --needed --noconfirm python-gobject gtk3 webkit2gtk-4.1" ;;
    *void*) echo "xbps-install -Sy python3-gobject gtk+3 libwebkit2gtk41" ;;
    *gentoo*) echo "emerge --noreplace dev-python/pygobject x11-libs/gtk+:3 net-libs/webkit-gtk:4.1" ;;
    *alpine*) echo "apk add python3 py3-gobject3 gtk+3.0 webkit2gtk-4.1" ;;
    *solus*) echo "eopkg install -y python-gobject libgtk-3 libwebkit-gtk41" ;;
    *mageia*) echo "urpmi python3-gobject3 lib64webkit2gtk-gir4.1" ;;
    *) echo "" ;;
  esac
}

have_deps() {
  python3 - <<'EOF' >/dev/null 2>&1
import gi
gi.require_version('Gtk', '3.0')
for v in ('4.1', '4.0'):
    try:
        gi.require_version('WebKit2', v)
        break
    except ValueError:
        pass
else:
    raise SystemExit(1)
from gi.repository import Gtk, WebKit2
EOF
}

# ------------------------------------------------------------------ uninstall

MANIFEST="$PREFIX/lib/crystal-ball/MANIFEST"
if [ "$ACTION" = uninstall ]; then
  if [ ! -f "$MANIFEST" ]; then echo "Crystal Ball is not installed in $PREFIX."; exit 1; fi
  while read -r f; do run rm -f "$PREFIX/$f"; done < "$MANIFEST"
  run rm -rf "$PREFIX/lib/crystal-ball" "$PREFIX/share/gnome-shell/extensions/crystal-ball@crystalball.app" \
    "$PREFIX/share/gnome-shell/extensions/crystal-ball-legacy@crystalball.app"
  echo "Crystal Ball removed from $PREFIX."
  exit 0
fi

# ------------------------------------------------------------------ install

if ! have_deps; then
  CMD=$(deps_command)
  if [ "$DEPS" = yes ] && [ -n "$CMD" ]; then
    echo "Installing dependencies: $CMD"
    if [ "$(id -u)" -eq 0 ]; then sh -c "$CMD"; elif command -v sudo >/dev/null 2>&1; then sudo sh -c "$CMD"; else su -c "$CMD"; fi
  else
    echo "Crystal Ball needs Python 3 with PyGObject, GTK 3 and WebKitGTK (WebKit2 4.1 or 4.0)."
    if [ -n "$CMD" ]; then
      echo "Install them with:  sudo $CMD"
      echo "or run:             $0 --deps $( [ "$MODE" = user ] && echo --user )"
    else
      echo "Install your distribution's packages for: python3 gobject bindings, gtk3 and webkit2gtk-4.1."
    fi
    exit 1
  fi
fi

echo "Installing Crystal Ball into $PREFIX"
cd "$HERE/files/usr"
run mkdir -p "$PREFIX"
# copy everything, then remember the files outside our own folders for --uninstall
run cp -R bin lib share "$PREFIX"/
find bin share -type f ! -path 'share/gnome-shell/*' | sed 's|^\./||' > "$HERE/MANIFEST.tmp"
run cp "$HERE/MANIFEST.tmp" "$MANIFEST"
rm -f "$HERE/MANIFEST.tmp"
run chmod 755 "$PREFIX/bin/crystal-ball" "$PREFIX/lib/crystal-ball/crystal-ball.py"

if [ "$MODE" = user ]; then
  # the menu may not search ~/.local/bin, so point the launcher entry at it directly
  sed -i "s|^Exec=crystal-ball|Exec=$PREFIX/bin/crystal-ball|" "$PREFIX/share/applications/app.crystalball.CrystalBall.desktop"
fi
command -v gtk-update-icon-cache >/dev/null 2>&1 && run gtk-update-icon-cache -q -t "$PREFIX/share/icons/hicolor" 2>/dev/null || true
command -v update-desktop-database >/dev/null 2>&1 && run update-desktop-database -q "$PREFIX/share/applications" 2>/dev/null || true

echo "Done. Open \"Crystal Ball\" from your applications menu, or run: $PREFIX/bin/crystal-ball"
if command -v gnome-shell >/dev/null 2>&1; then
  echo "On GNOME: open Crystal Ball once, then log out and back in so GNOME loads its window helper."
fi
