Crystal Ball 1.2.0 for any Linux distribution

Install for everyone:     ./install.sh
Install just for you:     ./install.sh --user
Also install dependencies: add --deps
Uninstall:                ./install.sh --uninstall   (add --user if you used it)

Needs Python 3 with PyGObject, GTK 3 and WebKitGTK (WebKit2 4.1 or 4.0).
On GNOME: open Crystal Ball once, then log out and back in.
