// Crystal Ball helper for GNOME Shell 40–44 (the pre-ESM extension format).
// Same D-Bus service as crystal-ball@crystalball.app, which covers GNOME 45 and later:
//
//   app.crystalball.Shell  /app/crystalball/Shell
//     Version() -> s
//     List(u exclude_pid) -> s            JSON array of windows, most recently used first
//     Thumb(u id, u max_size) -> s        path of a PNG snapshot of the window, or ''
//     Activate(u id) -> b                 switch workspace, unminimize and focus the window
/* exported init */

const {Gio, GLib, Meta, Shell} = imports.gi;
const Cairo = imports.cairo;
const Main = imports.ui.main;

const BUS_NAME = 'app.crystalball.Shell';
const OBJECT_PATH = '/app/crystalball/Shell';

const IFACE = `<node>
  <interface name="app.crystalball.Shell">
    <method name="Version">
      <arg type="s" direction="out" name="version"/>
    </method>
    <method name="List">
      <arg type="u" direction="in" name="exclude_pid"/>
      <arg type="s" direction="out" name="json"/>
    </method>
    <method name="Thumb">
      <arg type="u" direction="in" name="id"/>
      <arg type="u" direction="in" name="max_size"/>
      <arg type="s" direction="out" name="path"/>
    </method>
    <method name="Activate">
      <arg type="u" direction="in" name="id"/>
      <arg type="b" direction="out" name="ok"/>
    </method>
  </interface>
</node>`;

function asciiJson(value) {
    return JSON.stringify(value).replace(/[\u007f-\uffff']/g,
        c => `\\u${c.charCodeAt(0).toString(16).padStart(4, '0')}`);
}

function iconFile(gicon) {
    try {
        if (gicon instanceof Gio.FileIcon)
            return gicon.get_file().get_path() || '';
    } catch (e) {}
    return '';
}

function isListable(win) {
    if (win.is_skip_taskbar() || win.is_override_redirect())
        return false;
    const type = win.get_window_type();
    return type === Meta.WindowType.NORMAL || type === Meta.WindowType.DIALOG ||
        type === Meta.WindowType.UTILITY;
}

class CrystalBallService {
    constructor() {
        this._thumbDir = GLib.build_filenamev([GLib.get_user_runtime_dir(), 'crystal-ball', 'thumbs']);
        GLib.mkdir_with_parents(this._thumbDir, 0o700);
    }

    Version() {
        return '1';
    }

    _windows() {
        const seen = new Set();
        const wins = [];
        for (const w of global.display.get_tab_list(Meta.TabList.NORMAL_ALL, null)) {
            seen.add(w);
            wins.push(w);
        }
        for (const w of global.display.list_all_windows()) {
            if (!seen.has(w))
                wins.push(w);
        }
        return wins.filter(isListable);
    }

    List(excludePid) {
        const tracker = Shell.WindowTracker.get_default();
        const out = [];
        for (const w of this._windows()) {
            if (excludePid && w.get_pid() === excludePid)
                continue;
            const app = tracker.get_window_app(w);
            const gicon = app ? app.get_icon() : null;
            const ws = w.get_workspace();
            out.push({
                id: w.get_stable_sequence(),
                title: w.get_title() || '',
                appId: app ? app.get_id() || '' : '',
                appName: app ? app.get_name() || '' : '',
                wmClass: w.get_wm_class() || '',
                pid: w.get_pid(),
                icon: gicon ? gicon.to_string() : '',
                iconFile: iconFile(gicon),
                focused: w.has_focus(),
                minimized: w.minimized,
                workspace: ws ? ws.index() : -1,
            });
        }
        return asciiJson(out);
    }

    _find(id) {
        return global.display.list_all_windows().find(w => w.get_stable_sequence() === id) || null;
    }

    Thumb(id, maxSize) {
        const win = this._find(id);
        const actor = win ? win.get_compositor_private() : null;
        if (!actor)
            return '';
        try {
            const image = actor.get_image(null);
            if (!image)
                return '';
            const w = image.getWidth();
            const h = image.getHeight();
            if (w < 2 || h < 2)
                return '';
            const scale = Math.min(1, (maxSize || 480) / Math.max(w, h));
            const small = new Cairo.ImageSurface(Cairo.Format.ARGB32,
                Math.max(1, Math.round(w * scale)), Math.max(1, Math.round(h * scale)));
            const cr = new Cairo.Context(small);
            cr.scale(scale, scale);
            cr.setSourceSurface(image, 0, 0);
            cr.paint();
            cr.$dispose();
            const path = GLib.build_filenamev([this._thumbDir, `${id}.png`]);
            small.writeToPNG(path);
            small.finish();
            image.finish();
            return path;
        } catch (e) {
            return '';
        }
    }

    Activate(id) {
        const win = this._find(id);
        if (!win)
            return false;
        if (win.minimized)
            win.unminimize();
        Main.activateWindow(win, global.get_current_time());
        return true;
    }
}

class CrystalBallExtension {
    enable() {
        this._service = new CrystalBallService();
        this._dbus = Gio.DBusExportedObject.wrapJSObject(IFACE, this._service);
        this._dbus.export(Gio.DBus.session, OBJECT_PATH);
        this._nameId = Gio.bus_own_name_on_connection(Gio.DBus.session, BUS_NAME,
            Gio.BusNameOwnerFlags.REPLACE, null, null);
    }

    disable() {
        if (this._nameId) {
            Gio.bus_unown_name(this._nameId);
            this._nameId = 0;
        }
        if (this._dbus)
            this._dbus.unexport();
        this._dbus = null;
        this._service = null;
    }
}

function init() {
    return new CrystalBallExtension();
}
