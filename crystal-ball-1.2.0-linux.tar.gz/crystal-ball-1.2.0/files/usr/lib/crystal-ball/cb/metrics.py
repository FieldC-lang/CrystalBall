"""CPU, GPU and RAM usage, each as a fraction 0..1."""
import glob
import os
import re
import shutil
import subprocess
import time


def _read(path):
    with open(path) as f:
        return f.read()


# ---------------------------------------------------------------- CPU

def parse_stat(text):
    """(busy, total) jiffies from the aggregate "cpu" line of /proc/stat."""
    for line in text.splitlines():
        if line.startswith('cpu '):
            v = [int(x) for x in line.split()[1:9]]
            v += [0] * (8 - len(v))
            # user nice system idle iowait irq softirq steal (guest time is already in user/nice)
            total = sum(v)
            return total - v[3] - v[4], total
    return 0, 0


class CpuMeter:
    def __init__(self, read=lambda: _read('/proc/stat')):
        self.read = read
        self.last = parse_stat(self.read())

    def sample(self):
        """Fraction of CPU time spent busy since the previous sample."""
        now = parse_stat(self.read())
        busy = now[0] - self.last[0]
        total = now[1] - self.last[1]
        self.last = now
        return min(1.0, max(0.0, busy / total)) if total > 0 else 0.0


# ---------------------------------------------------------------- RAM

def parse_meminfo(text):
    """Fraction of RAM in use: 1 - MemAvailable / MemTotal."""
    vals = {}
    for line in text.splitlines():
        key, _, rest = line.partition(':')
        if key in ('MemTotal', 'MemAvailable', 'MemFree', 'Buffers', 'Cached'):
            vals[key] = int(rest.split()[0])
    total = vals.get('MemTotal', 0)
    if total <= 0:
        return 0.0
    avail = vals.get('MemAvailable', vals.get('MemFree', 0) + vals.get('Buffers', 0) + vals.get('Cached', 0))
    return min(1.0, max(0.0, 1 - avail / total))


def ram_used(read=lambda: _read('/proc/meminfo')):
    return parse_meminfo(read())


# ---------------------------------------------------------------- GPU

def parse_fdinfo(text):
    """(client key, {engine: busy ns}) from one DRM fdinfo file, or None if it has no engine counters."""
    client = pdev = None
    engines = {}
    for line in text.splitlines():
        key, _, value = line.partition(':')
        value = value.strip()
        if key == 'drm-client-id':
            client = value
        elif key == 'drm-pdev':
            pdev = value
        elif key.startswith('drm-engine-') and not key.startswith('drm-engine-capacity-'):
            m = re.match(r'(\d+)', value)
            if m:
                engines[key[11:]] = int(m.group(1))
    if not engines:
        return None
    return (pdev or '', client or ''), engines


def parse_v3d_stats(text):
    """{queue: (timestamp ns, runtime ns)} from the Raspberry Pi v3d gpu_stats file."""
    out = {}
    for line in text.splitlines()[1:]:
        parts = line.split()
        if len(parts) >= 4 and parts[1].isdigit():
            out[parts[0]] = (int(parts[1]), int(parts[3]))
    return out


class GpuMeter:
    """Picks the first GPU busy counter that works on this machine. sample() returns 0..1 or None."""

    def __init__(self):
        self.source = None
        self._prev = None
        for name, probe in (('AMD', self._probe_amd), ('NVIDIA', self._probe_nvidia),
                            ('DRM', self._probe_fdinfo), ('V3D', self._probe_v3d), ('Intel', self._probe_intel_freq)):
            try:
                if probe():
                    self.source = name
                    break
            except Exception:
                continue

    def sample(self):
        try:
            return {'AMD': self._amd, 'NVIDIA': self._nvidia, 'DRM': self._fdinfo, 'V3D': self._v3d,
                    'Intel': self._intel_freq}[self.source]() if self.source else None
        except Exception:
            return None

    # AMD: the driver keeps a busy percentage per card.
    def _probe_amd(self):
        self.amd_files = glob.glob('/sys/class/drm/card[0-9]*/device/gpu_busy_percent')
        return bool(self.amd_files) and self._amd() is not None

    def _amd(self):
        vals = []
        for f in self.amd_files:
            try:
                vals.append(int(_read(f).strip()))
            except (OSError, ValueError):
                pass
        return max(vals) / 100 if vals else None

    # NVIDIA's proprietary driver.
    def _probe_nvidia(self):
        return os.path.exists('/proc/driver/nvidia') and shutil.which('nvidia-smi') and self._nvidia() is not None

    def _nvidia(self):
        out = subprocess.run(['nvidia-smi', '--query-gpu=utilization.gpu', '--format=csv,noheader,nounits'],
                             capture_output=True, text=True, timeout=3).stdout
        vals = [int(x) for x in re.findall(r'\d+', out)]
        return max(vals) / 100 if vals else None

    # Any DRM driver with per-client engine counters (Intel i915/xe, v3d, panfrost, msm, …).
    def _fdinfo_totals(self):
        clients = {}
        for pid in os.listdir('/proc'):
            if not pid.isdigit():
                continue
            fd_dir = f'/proc/{pid}/fd'
            try:
                fds = os.listdir(fd_dir)
            except OSError:
                continue
            for fd in fds:
                try:
                    if not os.readlink(f'{fd_dir}/{fd}').startswith('/dev/dri/'):
                        continue
                    parsed = parse_fdinfo(_read(f'/proc/{pid}/fdinfo/{fd}'))
                except OSError:
                    continue
                if parsed:
                    clients[parsed[0]] = parsed[1]
        totals = {}
        for (pdev, _), engines in clients.items():
            for engine, ns in engines.items():
                totals[(pdev, engine)] = totals.get((pdev, engine), 0) + ns
        return totals

    def _probe_fdinfo(self):
        totals = self._fdinfo_totals()
        self._prev = (time.monotonic_ns(), totals)
        return bool(totals)

    def _fdinfo(self):
        now, totals = time.monotonic_ns(), self._fdinfo_totals()
        then, before = self._prev
        self._prev = (now, totals)
        wall = now - then
        if wall <= 0:
            return 0.0
        busy = max((ns - before.get(k, ns) for k, ns in totals.items()), default=0)
        return min(1.0, max(0.0, busy / wall))

    # Raspberry Pi v3d: per-queue runtime totals in sysfs.
    def _probe_v3d(self):
        self.v3d_files = glob.glob('/sys/class/drm/card[0-9]*/device/gpu_stats')
        if not self.v3d_files:
            return False
        self._prev = parse_v3d_stats(_read(self.v3d_files[0]))
        return bool(self._prev)

    def _v3d(self):
        now = parse_v3d_stats(_read(self.v3d_files[0]))
        before, self._prev = self._prev, now
        best = 0.0
        for q, (ts, rt) in now.items():
            if q in before and ts > before[q][0]:
                best = max(best, (rt - before[q][1]) / (ts - before[q][0]))
        return min(1.0, max(0.0, best))

    # Intel fallback: current frequency against the maximum (an estimate of load).
    def _probe_intel_freq(self):
        self.intel = []
        for card in glob.glob('/sys/class/drm/card[0-9]*'):
            for act, mx in (('gt/gt0/rps_act_freq_mhz', 'gt/gt0/rps_max_freq_mhz'), ('gt_act_freq_mhz', 'gt_max_freq_mhz')):
                if os.path.exists(f'{card}/{act}') and os.path.exists(f'{card}/{mx}'):
                    self.intel.append((f'{card}/{act}', f'{card}/{mx}'))
                    break
        return bool(self.intel)

    def _intel_freq(self):
        vals = [int(_read(a)) / max(1, int(_read(m))) for a, m in self.intel]
        return min(1.0, max(vals)) if vals else None
