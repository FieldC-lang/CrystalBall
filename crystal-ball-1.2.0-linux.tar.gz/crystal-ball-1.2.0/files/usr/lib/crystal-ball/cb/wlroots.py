"""wlroots backend (labwc, wayfire, sway, Hyprland…; Raspberry Pi OS uses labwc / wayfire).

A tiny Wayland client written straight on the wire protocol: it binds
zwlr_foreign_toplevel_manager_v1 to learn every toplevel's title, app_id and state, and asks the
compositor to activate the one you pick. None of the messages used carry file descriptors, so a
plain unix socket is enough.
"""
import os
import re
import socket
import struct

from .desktop import describe_app

MANAGER = 'zwlr_foreign_toplevel_manager_v1'
STATE_MINIMIZED = 1
STATE_ACTIVATED = 2
OWN_APP = re.compile(r'crystal[-_. ]?ball', re.I)


def u32(n):
    return struct.pack('<I', n & 0xFFFFFFFF)


def wl_str(s):
    body = s.encode() + b'\0'
    return u32(len(body)) + body + b'\0' * (-len(body) % 4)


def message(oid, opcode, *args):
    body = b''.join(args)
    return struct.pack('<II', oid, ((8 + len(body)) << 16) | opcode) + body


class Args:
    """Sequential reader over one message's arguments."""

    def __init__(self, buf):
        self.buf = buf
        self.off = 0

    def u32(self):
        (v,) = struct.unpack_from('<I', self.buf, self.off)
        self.off += 4
        return v

    def str(self):
        n = self.u32()
        if n == 0:
            return None
        s = self.buf[self.off:self.off + n - 1].decode('utf-8', 'replace')
        self.off += (n + 3) & ~3
        return s

    def array(self):
        n = self.u32()
        a = self.buf[self.off:self.off + n]
        self.off += (n + 3) & ~3
        return a


class Framer:
    """Splits a byte stream into complete (object_id, opcode, Args) messages."""

    def __init__(self):
        self.pending = b''

    def push(self, chunk):
        self.pending += chunk
        out = []
        while len(self.pending) >= 8:
            oid, word = struct.unpack_from('<II', self.pending)
            size = word >> 16
            if size < 8 or len(self.pending) < size:
                break
            out.append((oid, word & 0xFFFF, Args(self.pending[8:size])))
            self.pending = self.pending[size:]
        return out


class WlrBackend:
    name = 'wlroots'

    def __init__(self):
        self.notice = ''
        self.next_id = 2
        self.objects = {}
        self.globals = {}
        self.toplevels = {}
        self.order = 0
        self.activations = 0
        self.framer = Framer()
        self.sock = None
        self.seat = None

    def _socket_path(self):
        d = os.environ.get('WAYLAND_DISPLAY', 'wayland-0')
        return d if d.startswith('/') else os.path.join(os.environ.get('XDG_RUNTIME_DIR', f'/run/user/{os.getuid()}'), d)

    def _send(self, buf):
        self.sock.sendall(buf)

    def _new(self, handler):
        oid = self.next_id
        self.next_id += 1
        self.objects[oid] = handler
        return oid

    def _read(self):
        chunk = self.sock.recv(65536)
        if not chunk:
            raise ConnectionError('compositor closed the connection')
        for oid, op, args in self.framer.push(chunk):
            handler = self.objects.get(oid)
            if handler:
                handler(op, args)

    def _roundtrip(self):
        done = []
        cid = self._new(lambda op, a: done.append(True) if op == 0 else None)
        self._send(message(1, 0, u32(cid)))
        while not done:
            self._read()
        self.objects.pop(cid, None)

    def _display(self, op, a):
        if op == 0:
            obj, code, msg = a.u32(), a.u32(), a.str()
            raise ConnectionError(f'wayland error {obj}/{code}: {msg}')

    def _registry(self, op, a):
        if op == 0:
            name, iface, version = a.u32(), a.str(), a.u32()
            self.globals[iface] = (name, version)

    def _bind(self, glob, iface, version, handler):
        oid = self._new(handler)
        self._send(message(self.registry, 0, u32(glob[0]), wl_str(iface), u32(version), u32(oid)))
        return oid

    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(3)
        self.sock.connect(self._socket_path())
        self.objects[1] = self._display
        self.registry = self._new(self._registry)
        self._send(message(1, 1, u32(self.registry)))
        self._roundtrip()
        if MANAGER not in self.globals:
            raise ConnectionError(f'compositor does not offer {MANAGER}')
        if 'wl_seat' in self.globals:
            self.seat = self._bind(self.globals['wl_seat'], 'wl_seat', 1, lambda op, a: None)
        mgr = self.globals[MANAGER]
        self.manager = self._bind(mgr, MANAGER, min(mgr[1], 3),
                                  lambda op, a: self._add_toplevel(a.u32()) if op == 0 else None)
        self._roundtrip()
        self._roundtrip()

    def _add_toplevel(self, oid):
        t = {'id': oid, 'title': '', 'appId': '', 'state': [], 'created': self.order, 'active': 0, 'done': False}
        self.order += 1
        self.toplevels[oid] = t

        def handle(op, a):
            if op == 0:
                t['title'] = a.str() or ''
            elif op == 1:
                t['appId'] = a.str() or ''
            elif op == 4:
                arr = a.array()
                t['state'] = [struct.unpack_from('<I', arr, i)[0] for i in range(0, len(arr) - 3, 4)]
                if STATE_ACTIVATED in t['state']:
                    self.activations += 1
                    t['active'] = self.activations
            elif op == 5:
                t['done'] = True
            elif op == 6:
                self.toplevels.pop(oid, None)
                self.objects.pop(oid, None)
                self._send(message(oid, 7))
        self.objects[oid] = handle

    def setup(self):
        try:
            self.connect()
            return True
        except Exception as e:
            self.notice = f"The ball cannot see this desktop's windows ({e})."
            return False

    def list(self, exclude_pid=0):
        self._roundtrip()
        tops = [t for t in self.toplevels.values()
                if t['done'] and not OWN_APP.search(t['appId']) and t['title'] != 'Crystal Ball']
        tops.sort(key=lambda t: (t['active'], t['created']), reverse=True)
        out = []
        for t in tops:
            app = describe_app(t['appId'])
            out.append({
                'id': str(t['id']),
                'title': t['title'],
                'appName': app['appName'] or t['appId'] or 'Window',
                'appId': app['appId'],
                'iconFile': app['iconFile'],
                'focused': STATE_ACTIVATED in t['state'],
                'minimized': STATE_MINIMIZED in t['state'],
                'thumbs': False,
            })
        return out

    def thumb(self, wid, done):
        done('')

    def activate(self, wid):
        t = self.toplevels.get(int(wid))
        if not t or not self.seat:
            return False
        if STATE_MINIMIZED in t['state']:
            self._send(message(t['id'], 3))
        self._send(message(t['id'], 4, u32(self.seat)))
        self._roundtrip()
        return True

    def close(self):
        if self.sock:
            self.sock.close()
