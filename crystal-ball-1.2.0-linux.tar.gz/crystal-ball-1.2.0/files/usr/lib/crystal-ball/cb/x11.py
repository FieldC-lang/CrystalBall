"""X11 backend (Raspberry Pi OS legacy X11 / openbox, Xorg sessions): EWMH through wmctrl and xprop."""
import re
import subprocess

from .desktop import describe_app

OWN_APP = re.compile(r'^crystal[-_. ]?ball$|crystalball', re.I)
SKIP = re.compile(r'_NET_WM_WINDOW_TYPE_(DESKTOP|DOCK|SPLASH|NOTIFICATION|TOOLBAR|MENU)|_NET_WM_STATE_SKIP_TASKBAR')


def run(*cmd):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=3, check=True).stdout


def parse_wmctrl(text):
    """Windows from `wmctrl -lpx` output."""
    out = []
    for line in text.splitlines():
        m = re.match(r'^(0x[0-9a-f]+)\s+(-?\d+)\s+(\d+)\s+(\S+)\s+\S+(?:\s+(.*))?$', line, re.I)
        if not m:
            continue
        instance, _, cls = m.group(4).partition('.')
        out.append({'xid': m.group(1).lower(), 'desktop': int(m.group(2)), 'pid': int(m.group(3)),
                    'instance': instance, 'cls': cls or instance, 'title': m.group(5) or ''})
    return out


def parse_id_list(text):
    """Window ids from an xprop list property such as `_NET_CLIENT_LIST_STACKING(WINDOW): window id # 0x1, 0x2`."""
    return [hex(int(x, 16)) for x in re.findall(r'0x[0-9a-f]+', text, re.I)]


class X11Backend:
    name = 'x11'

    def __init__(self):
        self.notice = ''

    def setup(self):
        try:
            run('wmctrl', '-m')
            return True
        except Exception:
            self.notice = 'Install the "wmctrl" package so the ball can see your windows.'
            return False

    def list(self, exclude_pid=0):
        wins = parse_wmctrl(run('wmctrl', '-lpx'))
        try:
            stacking = parse_id_list(run('xprop', '-root', '_NET_CLIENT_LIST_STACKING'))
        except Exception:
            stacking = []
        rank = {x: i for i, x in enumerate(stacking)}
        keep = []
        for w in wins:
            if (exclude_pid and w['pid'] == exclude_pid) or OWN_APP.search(w['instance']):
                continue
            try:
                props = run('xprop', '-id', w['xid'], '_NET_WM_WINDOW_TYPE', '_NET_WM_STATE')
                if SKIP.search(props):
                    continue
                w['minimized'] = '_NET_WM_STATE_HIDDEN' in props
            except Exception:
                pass
            keep.append(w)
        keep.sort(key=lambda w: rank.get(hex(int(w['xid'], 16)), -1), reverse=True)
        out = []
        for i, w in enumerate(keep):
            app = describe_app(w['instance'], w['cls'])
            out.append({'id': w['xid'], 'title': w['title'], 'appName': app['appName'], 'appId': app['appId'],
                        'iconFile': app['iconFile'], 'focused': i == 0, 'minimized': w.get('minimized', False),
                        'thumbs': False})
        return out

    def thumb(self, wid, done):
        done('')

    def activate(self, wid):
        try:
            run('wmctrl', '-ia', wid)
            return True
        except Exception:
            return False

    def close(self):
        pass
