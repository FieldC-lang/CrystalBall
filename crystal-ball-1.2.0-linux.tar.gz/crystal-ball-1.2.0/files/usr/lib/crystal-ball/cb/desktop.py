"""Desktop entry and icon lookup for windows known only by app_id / WM_CLASS."""
import os

from gi.repository import Gio, Gtk

_apps = None


def _all_apps():
    global _apps
    if _apps is None:
        _apps = [a for a in Gio.AppInfo.get_all() if isinstance(a, Gio.DesktopAppInfo)]
    return _apps


def find_entry(*keys):
    """Best Gio.DesktopAppInfo for an app_id / WM_CLASS / instance name, or None."""
    apps = _all_apps()
    for raw in keys:
        if not raw:
            continue
        key = raw[:-8] if raw.endswith('.desktop') else raw
        low = key.lower()
        for cand in dict.fromkeys((key, low)):
            try:
                hit = Gio.DesktopAppInfo.new(cand + '.desktop')
            except TypeError:
                hit = None
            if hit:
                return hit
        tests = (
            lambda a: (a.get_startup_wm_class() or '').lower() == low,
            lambda a: (a.get_id() or '').lower().endswith('.' + low + '.desktop'),
            lambda a: not a.get_nodisplay() and os.path.basename(a.get_executable() or '').lower() == low,
            lambda a: not a.get_nodisplay() and (a.get_name() or '').lower() == low,
        )
        for test in tests:
            for a in apps:
                if test(a):
                    return a
    return None


def icon_file(gicon, size=256):
    """File behind a GIcon in the current icon theme, or ''."""
    if gicon is None:
        return ''
    if isinstance(gicon, Gio.FileIcon):
        path = gicon.get_file().get_path()
        return path if path and os.path.exists(path) else ''
    info = Gtk.IconTheme.get_default().lookup_by_gicon(gicon, size, Gtk.IconLookupFlags.FORCE_SIZE)
    return (info.get_filename() or '') if info else ''


def resolve_icon(icon):
    """Icon file for a theme icon name, an absolute path or a serialized GIcon, or ''."""
    if not icon:
        return ''
    if icon.startswith('/'):
        return icon if os.path.exists(icon) else ''
    try:
        return icon_file(Gio.Icon.new_for_string(icon))
    except Exception:
        return ''


def pretty(key):
    tail = key.split('.')[-1].replace('-', ' ').replace('_', ' ')
    return ' '.join(w[:1].upper() + w[1:] for w in tail.split())


def describe_app(*keys):
    """Display name, desktop id and icon file for a window known by app_id / WM_CLASS."""
    entry = find_entry(*keys)
    fallback = next((k for k in keys if k), '')
    icon = icon_file(entry.get_icon()) if entry else ''
    if not icon:
        icon = next((f for f in (resolve_icon(k) for k in keys if k) if f), '')
    return {
        'appId': entry.get_id() if entry else fallback,
        'appName': (entry.get_name() if entry else '') or pretty(fallback),
        'iconFile': icon,
    }
