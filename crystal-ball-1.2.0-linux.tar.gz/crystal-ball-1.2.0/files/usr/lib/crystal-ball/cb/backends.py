"""Picks the window backend for the running desktop."""
import os

from .desktop import describe_app


class NullBackend:
    name = 'none'

    def __init__(self, notice):
        self.notice = notice

    def list(self, exclude_pid=0):
        return []

    def thumb(self, wid, done):
        done('')

    def activate(self, wid):
        return False

    def close(self):
        pass


class DemoBackend(NullBackend):
    """Pretend windows for trying out shapes: CRYSTAL_BALL_DEMO=<count>."""
    name = 'demo'
    APPS = ['org.gnome.Nautilus', 'firefox', 'org.gnome.TextEditor', 'org.gnome.Calculator', 'org.gnome.Settings',
            'org.gnome.Terminal', 'thunderbird', 'org.gnome.clocks', 'org.gnome.Software', 'org.gnome.Calendar',
            'libreoffice-writer', 'gimp', 'code', 'org.gnome.Weather', 'yelp']

    def __init__(self, count):
        super().__init__('')
        self.windows = []
        for i in range(count):
            a = describe_app(self.APPS[i % len(self.APPS)])
            self.windows.append({'id': f'demo-{i}', 'title': f"{a['appName']} window {i + 1}", 'appName': a['appName'],
                                 'appId': a['appId'], 'iconFile': a['iconFile'], 'focused': i == 0,
                                 'minimized': False, 'thumbs': False})

    def list(self, exclude_pid=0):
        return self.windows

    def activate(self, wid):
        return True


def pick_backend():
    if os.environ.get('CRYSTAL_BALL_DEMO'):
        return DemoBackend(int(os.environ['CRYSTAL_BALL_DEMO'] or 0))
    desktop = os.environ.get('XDG_CURRENT_DESKTOP', '').lower()
    gnome_notice = ''
    if any(d in desktop for d in ('gnome', 'ubuntu', 'unity', 'pop')):
        from .gnome import GnomeBackend
        g = GnomeBackend()
        if g.setup():
            return g
        gnome_notice = g.notice
    if os.environ.get('WAYLAND_DISPLAY') and not gnome_notice:
        from .wlroots import WlrBackend
        w = WlrBackend()
        if w.setup():
            return w
        if not os.environ.get('DISPLAY'):
            return NullBackend(w.notice)
    if os.environ.get('DISPLAY'):
        from .x11 import X11Backend
        x = X11Backend()
        if x.setup():
            if gnome_notice:
                x.notice = gnome_notice
            return x
        if not gnome_notice:
            return NullBackend(x.notice)
    return NullBackend(gnome_notice or 'The ball cannot see the windows on this desktop.')
