"""GNOME Shell backend: talks to the bundled crystal-ball@crystalball.app extension over D-Bus."""
import json
import os

from gi.repository import Gio, GLib

from .desktop import describe_app, resolve_icon

UUID = 'crystal-ball@crystalball.app'
LEGACY_UUID = 'crystal-ball-legacy@crystalball.app'
NAME = 'app.crystalball.Shell'
PATH = '/app/crystalball/Shell'


def extension_installed(uuid):
    data = [os.environ.get('XDG_DATA_HOME') or os.path.expanduser('~/.local/share')]
    data += (os.environ.get('XDG_DATA_DIRS') or '/usr/local/share:/usr/share').split(':')
    data += ['/usr/local/share', '/usr/share']
    return any(os.path.exists(os.path.join(d, 'gnome-shell/extensions', uuid, 'extension.js')) for d in data if d)


def shell_settings():
    source = Gio.SettingsSchemaSource.get_default()
    if source and source.lookup('org.gnome.shell', True):
        return Gio.Settings.new('org.gnome.shell')
    return None


class GnomeBackend:
    name = 'gnome'

    def __init__(self):
        self.notice = ''
        self.bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)

    def _call(self, method, params=None, reply='(s)', timeout=3000):
        return self.bus.call_sync(NAME, PATH, NAME, method, params, GLib.VariantType(reply),
                                  Gio.DBusCallFlags.NONE, timeout, None).unpack()[0]

    def ready(self):
        try:
            return bool(self._call('Version', timeout=1000))
        except GLib.Error:
            return False

    def extension_uuid(self):
        """The extension build for the running GNOME Shell: ESM for 45+, the legacy one for 40–44."""
        try:
            version = self.bus.call_sync('org.gnome.Shell', '/org/gnome/Shell', 'org.freedesktop.DBus.Properties', 'Get',
                                         GLib.Variant('(ss)', ('org.gnome.Shell', 'ShellVersion')),
                                         GLib.VariantType('(v)'), Gio.DBusCallFlags.NONE, 1000, None).unpack()[0]
            return LEGACY_UUID if int(str(version).split('.')[0]) < 45 else UUID
        except (GLib.Error, ValueError):
            return UUID

    def setup(self):
        """Makes sure the extension is enabled. True when it is already answering."""
        if self.ready():
            return True
        uuid = self.extension_uuid()
        if not extension_installed(uuid):
            self.notice = 'The Crystal Ball GNOME extension is missing. Reinstall the crystal-ball package to restore it.'
            return False
        enabled = False
        try:
            enabled = self.bus.call_sync('org.gnome.Shell.Extensions', '/org/gnome/Shell/Extensions',
                                         'org.gnome.Shell.Extensions', 'EnableExtension',
                                         GLib.Variant('(s)', (uuid,)), GLib.VariantType('(b)'),
                                         Gio.DBusCallFlags.NONE, 2000, None).unpack()[0]
        except GLib.Error:
            pass
        settings = shell_settings()
        if not enabled and settings:
            on = list(settings.get_strv('enabled-extensions'))
            if uuid not in on:
                settings.set_strv('enabled-extensions', on + [uuid])
            off = list(settings.get_strv('disabled-extensions'))
            if uuid in off:
                settings.set_strv('disabled-extensions', [u for u in off if u != uuid])
            Gio.Settings.sync()
        for _ in range(6):
            if self.ready():
                return True
            GLib.usleep(250000)
        if settings and settings.get_boolean('disable-user-extensions'):
            self.notice = ('GNOME extensions are switched off. Turn them on in the Extensions app, '
                           'then log out and back in, so the ball can see your windows.')
        else:
            self.notice = 'The ball is attuning to GNOME. Log out and back in once so it can see your windows.'
        return False

    def list(self, exclude_pid):
        out = []
        for w in json.loads(self._call('List', GLib.Variant('(u)', (exclude_pid,)))):
            app = None if w['appName'] and w['iconFile'] else describe_app(w['appId'], w['wmClass'])
            out.append({
                'id': str(w['id']),
                'title': w['title'],
                'appName': w['appName'] or (app and app['appName']) or w['wmClass'] or 'Window',
                'appId': w['appId'] or w['wmClass'],
                'iconFile': w['iconFile'] or resolve_icon(w['icon']) or (app and app['iconFile']) or '',
                'focused': w['focused'],
                'minimized': w['minimized'],
                'thumbs': True,
            })
        return out

    def thumb(self, wid, done, size=480):
        """Calls done(path or '') once the extension has written the snapshot."""
        def finish(bus, res):
            try:
                done(bus.call_finish(res).unpack()[0])
            except GLib.Error:
                done('')
        self.bus.call(NAME, PATH, NAME, 'Thumb', GLib.Variant('(uu)', (int(wid), size)), GLib.VariantType('(s)'),
                      Gio.DBusCallFlags.NONE, 3000, None, finish)

    def activate(self, wid):
        try:
            return self._call('Activate', GLib.Variant('(u)', (int(wid),)), reply='(b)')
        except GLib.Error:
            return False

    def close(self):
        pass
