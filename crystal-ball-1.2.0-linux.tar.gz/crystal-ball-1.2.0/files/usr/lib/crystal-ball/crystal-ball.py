#!/usr/bin/env python3
"""Crystal Ball: a full-screen, transparent scrying overlay (GTK 3 + the system WebKitGTK)."""
import json
import os
import socket
import sys
import threading
import time

HERE = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, HERE)

import gi  # noqa: E402

gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
for _webkit in ('4.1', '4.0'):
    try:
        gi.require_version('WebKit2', _webkit)
        break
    except ValueError:
        continue
from gi.repository import Gdk, Gio, GLib, Gtk, WebKit2  # noqa: E402

from cb.backends import pick_backend  # noqa: E402
from cb.metrics import CpuMeter, GpuMeter, ram_used  # noqa: E402

APP_ID = 'app.crystalball.CrystalBall'
RENDERER = os.path.join(HERE, 'renderer')


def js_eval(web, script, done=None):
    """Runs script in the page; done(json_text or None) gets the result for callers that want it."""
    def finish(view, res):
        try:
            if hasattr(view, 'evaluate_javascript_finish'):
                value = view.evaluate_javascript_finish(res)
            else:
                value = view.run_javascript_finish(res).get_js_value()
            done(value.to_string() if value is not None else None)
        except GLib.Error as e:
            done(json.dumps({'error': e.message}))
    callback = finish if done else None
    if hasattr(web, 'evaluate_javascript'):
        web.evaluate_javascript(script, -1, None, None, None, callback)
    else:
        web.run_javascript(script, None, callback)


class CrystalBall(Gtk.Application):
    def __init__(self):
        flags = getattr(Gio.ApplicationFlags, 'DEFAULT_FLAGS', Gio.ApplicationFlags.FLAGS_NONE)
        super().__init__(application_id=APP_ID, flags=flags)
        self.win = None
        self.web = None
        self.backend = None
        self.closing = False
        self.focused_once = False

    # ------------------------------------------------------------ window

    def do_activate(self):
        if self.win:
            self.event('dismiss')
            return
        self.backend = pick_backend()

        win = Gtk.ApplicationWindow(application=self)
        win.set_title('Crystal Ball')
        win.set_decorated(False)
        win.set_skip_taskbar_hint(True)
        win.set_skip_pager_hint(True)
        win.set_keep_above(True)
        win.set_app_paintable(True)
        win.set_icon_name('crystal-ball')
        visual = win.get_screen().get_rgba_visual()
        if visual:
            win.set_visual(visual)
        css = Gtk.CssProvider()
        css.load_from_data(b'window, .background { background-color: rgba(0, 0, 0, 0); }')
        Gtk.StyleContext.add_provider_for_screen(win.get_screen(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        content = WebKit2.UserContentManager()
        with open(os.path.join(RENDERER, 'bridge.js')) as f:
            content.add_script(WebKit2.UserScript(f.read(), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                                                  WebKit2.UserScriptInjectionTime.START, None, None))
        content.connect('script-message-received::crystal', self.on_message)
        content.register_script_message_handler('crystal')
        web = WebKit2.WebView.new_with_user_content_manager(content)
        settings = web.get_settings()
        settings.set_allow_file_access_from_file_urls(True)
        settings.set_allow_universal_access_from_file_urls(True)
        settings.set_enable_write_console_messages_to_stdout(bool(os.environ.get('CRYSTAL_BALL_DEBUG')))
        settings.set_enable_developer_extras(bool(os.environ.get('CRYSTAL_BALL_DEBUG')))
        web.set_background_color(Gdk.RGBA(0, 0, 0, 0))
        web.connect('context-menu', lambda *a: True)
        win.add(web)

        win.connect('focus-in-event', self.on_focus_in)
        win.connect('focus-out-event', self.on_focus_out)
        win.connect('destroy', lambda *a: self.quit_now())
        self.win, self.web = win, web
        web.load_uri(GLib.filename_to_uri(os.path.join(RENDERER, 'index.html'), None))
        win.fullscreen()
        win.show_all()
        win.present()
        threading.Thread(target=self.sample_metrics, daemon=True).start()
        if os.environ.get('CRYSTAL_BALL_TEST_SOCKET'):
            self.test_server(os.environ['CRYSTAL_BALL_TEST_SOCKET'])

    def on_focus_in(self, *_):
        self.focused_once = True

    def on_focus_out(self, *_):
        if self.focused_once and not self.closing and not os.environ.get('CRYSTAL_BALL_KEEP'):
            self.event('dismiss')

    def sample_metrics(self):
        """Background thread: CPU, GPU and RAM usage pushed to the page every 0.4 s."""
        cpu = CpuMeter()
        gpu = GpuMeter()
        gpu_value = None
        n = 0
        while not self.closing:
            time.sleep(0.4)
            if n % 2 == 0:
                gpu_value = gpu.sample()
            n += 1
            data = {'cpu': cpu.sample(), 'gpu': gpu_value, 'ram': ram_used(), 'gpuSource': gpu.source}
            GLib.idle_add(self.push_metrics, data)

    def push_metrics(self, data):
        if not self.closing:
            self.event('metrics', data)
        return False

    def event(self, name, value=None):
        if self.web:
            js_eval(self.web, f'window.__crystalEvent && __crystalEvent({json.dumps(name)}, {json.dumps(value)})')

    def reply(self, rid, ok, value):
        if self.web and not self.closing:
            js_eval(self.web, f'__crystalReply({rid}, {json.dumps(ok)}, {json.dumps(value)})')

    # ------------------------------------------------------------ requests from the page

    def on_message(self, _manager, message):
        value = message.get_js_value() if hasattr(message, 'get_js_value') else message
        req = json.loads(value.to_string())
        rid, method, args = req['id'], req['method'], req.get('args', [])
        try:
            if method == 'state':
                self.reply(rid, True, {'backend': self.backend.name, 'notice': self.backend.notice or ''})
            elif method == 'list':
                try:
                    wins = self.backend.list(os.getpid())
                except Exception:
                    wins = []
                self.reply(rid, True, wins)
            elif method == 'thumb':
                self.backend.thumb(args[0], lambda path: self.reply(rid, True, path or ''))
            elif method == 'activate':
                self.closing = True
                self.win.hide()
                GLib.timeout_add(80, self.activate_and_quit, args[0])
            elif method == 'quit':
                self.closing = True
                self.quit_now()
            else:
                self.reply(rid, False, f'unknown method {method}')
        except Exception as e:
            self.reply(rid, False, str(e))

    def activate_and_quit(self, wid):
        try:
            self.backend.activate(wid)
        except Exception:
            pass
        self.quit_now()
        return False

    def quit_now(self):
        self.closing = True
        if self.backend:
            self.backend.close()
            self.backend = None
        self.quit()

    # ------------------------------------------------------------ test hook

    def test_server(self, path):
        """CRYSTAL_BALL_TEST_SOCKET=<path>: each connection sends one JS expression and gets its JSON back."""
        if os.path.exists(path):
            os.unlink(path)
        srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        srv.bind(path)
        srv.listen(4)
        self._test_srv = srv

        def accept(*_):
            conn, _ = srv.accept()
            data = b''
            while not data.endswith(b'\n'):
                chunk = conn.recv(65536)
                if not chunk:
                    break
                data += chunk
            expr = data.decode().strip()

            def done(result):
                try:
                    conn.sendall(((result or 'null') + '\n').encode())
                finally:
                    conn.close()
            js_eval(self.web, f'JSON.stringify((() => {{ return ({expr}); }})())', done)
            return True
        GLib.io_add_watch(srv.fileno(), GLib.IO_IN, accept)


def main():
    GLib.set_prgname(APP_ID)
    GLib.set_application_name('Crystal Ball')
    return CrystalBall().run(sys.argv[:1])


if __name__ == '__main__':
    sys.exit(main())
